# AiShort Backend (Java Spring Boot + MyBatis)

Java Spring Boot 后端服务，使用 **JDK 8** 和 **MyBatis**，用于替换 `https://api.newzone.top/api`。

## 技术栈

- **JDK**: 1.8
- **Spring Boot**: 2.7.18
- **ORM**: MyBatis
- **数据库**: H2 (开发) / MySQL (生产)
- **安全**: Spring Security + JWT
- **构建工具**: Maven

## 项目结构

```
backend/
├── src/main/java/com/aishort/backend/
│   ├── config/          # 配置类
│   ├── controller/      # API 控制器
│   ├── dto/             # 数据传输对象
│   ├── entity/          # 数据库实体
│   ├── mapper/          # MyBatis Mapper
│   ├── security/        # 安全配置
│   └── service/         # 业务逻辑层
├── src/main/resources/
│   ├── application.yml  # 应用配置
│   ├── schema.sql       # 数据库初始化脚本
│   └── mapper/          # MyBatis XML (可选)
├── Dockerfile           # Docker 配置
└── pom.xml              # Maven 配置
```

## 快速开始

### 1. 前置要求

- JDK 1.8
- Maven 3.6+
- MySQL 5.7+ (可选，默认使用 H2)

### 2. 构建项目

```bash
cd backend
mvn clean install
```

### 3. 运行项目

```bash
mvn spring-boot:run
```

服务将启动在 `http://localhost:8080/api`

### 4. 修改前端配置

编辑前端文件 `src/api/config.ts`：

```typescript
// 修改前
export const API_URL = "https://api.newzone.top/api";

// 修改后  
export const API_URL = "http://localhost:8080/api";
```

## 数据库配置

### H2 (默认，开发环境)

```yaml
spring:
  datasource:
    url: jdbc:h2:mem:aishortdb;DB_CLOSE_DELAY=-1
    driver-class-name: org.h2.Driver
    username: sa
    password:
  h2:
    console:
      enabled: true
      path: /h2-console
```

访问 H2 Console: `http://localhost:8080/api/h2-console`

### MySQL (生产环境)

```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/aishort?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true
    driver-class-name: com.mysql.jdbc.Driver
    username: root
    password: password
```

## 配置说明

### 环境变量

```bash
# 数据库
export JDBC_URL=jdbc:mysql://localhost:3306/aishort
export JDBC_USERNAME=root
export JDBC_PASSWORD=password

# JWT
export JWT_SECRET=your-secret-key

# 邮件
export MAIL_USERNAME=your-email@gmail.com
export MAIL_PASSWORD=your-app-password

# 前端地址
export FRONTEND_URL=http://localhost:3000
```

## API 端点

### 认证
- `POST /api/auth/local/register` - 注册
- `POST /api/auth/local` - 登录
- `POST /api/auth/change-password` - 修改密码
- `POST /api/auth/forgot-password` - 忘记密码
- `POST /api/auth/reset-password` - 重置密码
- `POST /api/auth/passwordless/send-link` - 免密登录链接
- `GET /api/auth/passwordless/login` - 免密登录

### 用户
- `GET /api/users/me` - 获取当前用户
- `PUT /api/favorites/update-username` - 更新用户名

### 提示词
- `GET /api/userprompts` - 获取社区提示词列表
- `POST /api/userprompts` - 创建提示词
- `PUT /api/userprompts/{id}` - 更新提示词
- `DELETE /api/userprompts/{id}` - 删除提示词
- `POST /api/userprompts/bulk` - 批量获取
- `POST /api/userprompts/favorbulk` - 批量获取收藏
- `GET /api/userprompts/check-updates` - 检查更新
- `POST /api/userprompts/{id}/vote` - 投票

### 收藏
- `POST /api/favorites` - 创建收藏
- `PUT /api/favorites/{id}` - 更新收藏
- `PATCH /api/favorites/myspace-order` - 更新排序
- `PATCH /api/favorites/custom-tags` - 更新标签

### 我的空间
- `GET /api/myspace` - 获取我的空间数据

### 评论
- `GET /api/comments/api::{type}.{type}:{id}/flat` - 获取评论
- `POST /api/comments/api::{type}.{type}:{pageId}` - 发表评论

### 卡片
- `POST /api/cards/bulk` - 批量获取卡片
- `GET /api/cards/find-with-tag` - 搜索卡片
- `GET /api/cards/allcounts` - 获取复制次数
- `POST /api/cards/{id}/copy` - 更新复制次数

## 部署

### Docker

```bash
docker build -t aishort-backend .
docker run -p 8080:8080 aishort-backend
```

### 生产环境

1. 使用 MySQL 数据库
2. 配置 HTTPS
3. 设置环境变量
4. 使用反向代理 (Nginx)

## 数据迁移

### 从原 Strapi 导出数据

```bash
# 导出卡片数据 (278条)
mysqldump -u root -p aishort cards card_tags card_counts > cards.sql

# 导出用户数据
mysqldump -u root -p aishort users user_prompts favorites comments > users.sql
```

## MyBatis Mapper

所有 Mapper 位于 `com.aishort.backend.mapper` 包下，使用注解方式配置 SQL。

如需复杂 SQL，可在 `src/main/resources/mapper/` 下创建 XML 文件。

## 注意事项

1. JDK 版本严格限制为 1.8
2. MyBatis 替代 JPA，无自动建表功能，使用 schema.sql
3. 所有实体类移除 JPA 注解
4. JWT 使用 jjwt 0.9.1 版本 (兼容 JDK 8)
