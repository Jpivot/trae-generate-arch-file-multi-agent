package com.aishort.backend.dto;

import lombok.Data;

import java.util.List;

@Data
public class BulkRequest {
    
    private List<Integer> ids;
    private String lang;
}
