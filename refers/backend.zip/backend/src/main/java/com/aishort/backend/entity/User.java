package com.aishort.backend.entity;

import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class User implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private String username;
    private String email;
    private String password;
    private String provider;
    private String providerId;
    private String resetPasswordToken;
    private LocalDateTime resetPasswordExpires;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Long version;
    
    // 关联属性，非数据库字段
    @Builder.Default
    private List<UserPrompt> userPrompts = null;
    private Favorite favorite = null;
}
