package com.aishort.backend.entity;

import lombok.*;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CardCount implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private Long cardId;
    private Integer copyCount;
}
