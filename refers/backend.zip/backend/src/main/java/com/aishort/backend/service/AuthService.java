package com.aishort.backend.service;

import com.aishort.backend.dto.*;
import com.aishort.backend.entity.Favorite;
import com.aishort.backend.entity.PasswordlessToken;
import com.aishort.backend.entity.User;
import com.aishort.backend.mapper.FavoriteMapper;
import com.aishort.backend.mapper.PasswordlessTokenMapper;
import com.aishort.backend.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class AuthService implements UserDetailsService {
    
    private final UserMapper userMapper;
    private final FavoriteMapper favoriteMapper;
    private final PasswordlessTokenMapper passwordlessTokenMapper;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final EmailService emailService;
    
    @Value("${app.passwordless.token-expiration}")
    private long passwordlessTokenExpiration;
    
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userMapper.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("User not found: " + username);
        }
        
        return new org.springframework.security.core.userdetails.User(
                user.getUsername(),
                user.getPassword(),
                new ArrayList<>()
        );
    }
    
    public User loadUserByUsernameForToken(String username) throws UsernameNotFoundException {
        User user = userMapper.findByUsername(username);
        if (user == null) {
            throw new UsernameNotFoundException("User not found: " + username);
        }
        return user;
    }
    
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userMapper.existsByUsername(request.getUsername())) {
            throw new RuntimeException("Username already exists");
        }
        if (userMapper.existsByEmail(request.getEmail())) {
            throw new RuntimeException("Email already exists");
        }
        
        User user = User.builder()
                .username(request.getUsername())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .provider("local")
                .build();
        
        userMapper.insert(user);
        
        // Create default favorite
        Favorite favorite = Favorite.builder()
                .userId(user.getId())
                .loves(new ArrayList<>())
                .commLoves(new ArrayList<>())
                .build();
        favoriteMapper.insert(favorite);
        
        String jwt = jwtService.generateToken(loadUserByUsername(user.getUsername()));
        
        return AuthResponse.builder()
                .jwt(jwt)
                .user(mapToUserDTO(user))
                .build();
    }
    
    public AuthResponse login(LoginRequest request) {
        User user = userMapper.findByUsername(request.getIdentifier());
        if (user == null) {
            user = userMapper.findByEmail(request.getIdentifier());
        }
        
        if (user == null || !passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new BadCredentialsException("Invalid credentials");
        }
        
        String jwt = jwtService.generateToken(loadUserByUsername(user.getUsername()));
        
        return AuthResponse.builder()
                .jwt(jwt)
                .user(mapToUserDTO(user))
                .build();
    }
    
    @Transactional
    public void changePassword(Long userId, PasswordChangeRequest request) {
        User user = userMapper.findById(userId);
        if (user == null) {
            throw new RuntimeException("User not found");
        }
        
        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
            throw new BadCredentialsException("Current password is incorrect");
        }
        
        if (!request.getNewPassword().equals(request.getConfirmPassword())) {
            throw new RuntimeException("New passwords do not match");
        }
        
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userMapper.update(user);
    }
    
    @Transactional
    public void forgotPassword(PasswordResetRequest request) {
        User user = userMapper.findByEmail(request.getEmail());
        if (user == null) {
            // Don't reveal if email exists
            return;
        }
        
        String token = UUID.randomUUID().toString();
        user.setResetPasswordToken(token);
        user.setResetPasswordExpires(LocalDateTime.now().plusHours(1));
        userMapper.update(user);
        
        emailService.sendPasswordResetEmail(user.getEmail(), token);
    }
    
    @Transactional
    public void resetPassword(PasswordResetConfirmRequest request) {
        User user = userMapper.findByResetPasswordToken(request.getCode());
        if (user == null) {
            throw new RuntimeException("Invalid or expired token");
        }
        
        if (user.getResetPasswordExpires().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Token has expired");
        }
        
        if (!request.getPassword().equals(request.getPasswordConfirmation())) {
            throw new RuntimeException("Passwords do not match");
        }
        
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setResetPasswordToken(null);
        user.setResetPasswordExpires(null);
        userMapper.update(user);
    }
    
    @Transactional
    public void sendPasswordlessLink(PasswordlessRequest request) {
        User user = userMapper.findByEmail(request.getEmail());
        
        // Always return success to prevent email enumeration
        if (user == null) {
            return;
        }
        
        // Invalidate old tokens
        PasswordlessToken existingToken = passwordlessTokenMapper.findValidByEmail(
                request.getEmail(), LocalDateTime.now());
        if (existingToken != null) {
            existingToken.setIsUsed(true);
            passwordlessTokenMapper.updateUsed(existingToken.getId(), true);
        }
        
        // Create new token
        String loginToken = UUID.randomUUID().toString();
        PasswordlessToken token = PasswordlessToken.builder()
                .email(request.getEmail())
                .loginToken(loginToken)
                .userId(user.getId())
                .expiresAt(LocalDateTime.now().plusSeconds(passwordlessTokenExpiration / 1000))
                .isUsed(false)
                .build();
        
        passwordlessTokenMapper.insert(token);
        
        emailService.sendPasswordlessLoginEmail(request.getEmail(), loginToken);
    }
    
    @Transactional
    public AuthResponse loginWithToken(String loginToken) {
        PasswordlessToken token = passwordlessTokenMapper.findByLoginToken(loginToken);
        if (token == null) {
            throw new BadCredentialsException("Invalid token");
        }
        
        if (token.getIsUsed() || token.isExpired()) {
            throw new BadCredentialsException("Token has expired or been used");
        }
        
        passwordlessTokenMapper.updateUsed(token.getId(), true);
        
        User user = userMapper.findById(token.getUserId());
        if (user == null) {
            throw new BadCredentialsException("User not found");
        }
        
        String jwt = jwtService.generateToken(loadUserByUsername(user.getUsername()));
        
        return AuthResponse.builder()
                .jwt(jwt)
                .user(mapToUserDTO(user))
                .build();
    }
    
    private UserDTO mapToUserDTO(User user) {
        return UserDTO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .provider(user.getProvider())
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getUpdatedAt())
                .build();
    }
}
