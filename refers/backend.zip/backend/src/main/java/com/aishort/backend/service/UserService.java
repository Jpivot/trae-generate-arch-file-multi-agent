package com.aishort.backend.service;

import com.aishort.backend.dto.UserDTO;
import com.aishort.backend.dto.UserPromptDTO;
import com.aishort.backend.entity.User;
import com.aishort.backend.entity.UserPrompt;
import com.aishort.backend.mapper.UserMapper;
import com.aishort.backend.mapper.UserPromptMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserService {
    
    private final UserMapper userMapper;
    private final UserPromptMapper userPromptMapper;
    
    public UserDTO getUserMe(Long userId) {
        User user = userMapper.findById(userId);
        if (user == null) {
            throw new RuntimeException("User not found");
        }
        
        List<UserPrompt> userPrompts = userPromptMapper.findByUserId(userId);
        
        List<UserPromptDTO> userPromptDTOs = userPrompts.stream()
                .map(up -> UserPromptDTO.builder()
                        .id(up.getId())
                        .title(up.getTitle())
                        .description(up.getDescription())
                        .remark(up.getRemark())
                        .notes(up.getNotes())
                        .promptLength(up.getPromptLength())
                        .shared(up.getShared())
                        .upvotes(up.getUpvotes())
                        .downvotes(up.getDownvotes())
                        .upvoteDifference(up.getUpvoteDifference())
                        .userId(user.getId())
                        .username(user.getUsername())
                        .createdAt(up.getCreatedAt())
                        .updatedAt(up.getUpdatedAt())
                        .build())
                .collect(Collectors.toList());
        
        return UserDTO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .email(user.getEmail())
                .provider(user.getProvider())
                .createdAt(user.getCreatedAt())
                .updatedAt(user.getUpdatedAt())
                .userprompts(userPromptDTOs)
                .build();
    }
    
    public void updateUsername(Long userId, String newUsername) {
        User user = userMapper.findById(userId);
        if (user == null) {
            throw new RuntimeException("User not found");
        }
        
        if (userMapper.existsByUsername(newUsername)) {
            throw new RuntimeException("Username already exists");
        }
        
        user.setUsername(newUsername);
        userMapper.update(user);
    }
}
