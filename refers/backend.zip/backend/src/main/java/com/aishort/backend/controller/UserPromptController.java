package com.aishort.backend.controller;

import com.aishort.backend.dto.*;
import com.aishort.backend.service.UserPromptService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/userprompts")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class UserPromptController {
    
    private final UserPromptService userPromptService;
    
    @GetMapping
    public ResponseEntity<ApiResponse<Map<String, Object>>> getCommPrompts(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int pageSize,
            @RequestParam(defaultValue = "upvotes") String sortField,
            @RequestParam(defaultValue = "desc") String sortOrder,
            @RequestParam(required = false) String search) {
        Map<String, Object> result = userPromptService.getCommPrompts(page, pageSize, sortField, sortOrder, search);
        return ResponseEntity.ok(ApiResponse.success(result));
    }
    
    @PostMapping
    public ResponseEntity<ApiResponse<UserPromptDTO>> createPrompt(
            @RequestAttribute("userId") Long userId,
            @Valid @RequestBody UserPromptRequest request) {
        UserPromptDTO prompt = userPromptService.createPrompt(userId, request);
        return ResponseEntity.ok(ApiResponse.success(prompt));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<UserPromptDTO>> updatePrompt(
            @RequestAttribute("userId") Long userId,
            @PathVariable Long id,
            @Valid @RequestBody UserPromptRequest request) {
        UserPromptDTO prompt = userPromptService.updatePrompt(userId, id, request);
        return ResponseEntity.ok(ApiResponse.success(prompt));
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> deletePrompt(
            @RequestAttribute("userId") Long userId,
            @PathVariable Long id) {
        userPromptService.deletePrompt(userId, id);
        return ResponseEntity.ok(ApiResponse.success("Prompt deleted", null));
    }
    
    @PostMapping("/bulk")
    public ResponseEntity<ApiResponse<List<UserPromptDTO>>> getBulkPrompts(
            @RequestBody BulkRequest request) {
        List<UserPromptDTO> prompts = userPromptService.getPromptsByIds("commus", request.getIds(), null);
        return ResponseEntity.ok(ApiResponse.success(prompts));
    }
    
    @PostMapping("/favorbulk")
    public ResponseEntity<ApiResponse<List<UserPromptDTO>>> getFavorBulkPrompts(
            @RequestAttribute("userId") Long userId,
            @RequestBody BulkRequest request) {
        List<UserPromptDTO> prompts = userPromptService.getPromptsByIds("userprompts", request.getIds(), userId);
        return ResponseEntity.ok(ApiResponse.success(prompts));
    }
    
    @GetMapping("/check-updates")
    public ResponseEntity<ApiResponse<List<Map<String, Object>>>> checkUpdates(
            @RequestParam List<Integer> ids) {
        List<Map<String, Object>> updates = userPromptService.checkUpdates(ids);
        return ResponseEntity.ok(ApiResponse.success(updates));
    }
    
    @PostMapping("/{id}/vote")
    public ResponseEntity<ApiResponse<VoteResponse>> voteOnPrompt(
            @PathVariable Long id,
            @Valid @RequestBody VoteRequest request) {
        VoteResponse response = userPromptService.voteOnPrompt(id, request.getAction());
        return ResponseEntity.ok(ApiResponse.success(response));
    }
}
