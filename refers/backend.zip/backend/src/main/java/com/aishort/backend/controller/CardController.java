package com.aishort.backend.controller;

import com.aishort.backend.dto.ApiResponse;
import com.aishort.backend.dto.BulkRequest;
import com.aishort.backend.dto.CardDTO;
import com.aishort.backend.service.CardService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/cards")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class CardController {
    
    private final CardService cardService;
    
    @PostMapping("/bulk")
    public ResponseEntity<ApiResponse<List<CardDTO>>> getCardsBulk(
            @RequestBody BulkRequest request) {
        List<CardDTO> cards = cardService.getCardsByIds(request.getIds(), 
                request.getLang() != null ? request.getLang() : "zh-Hans");
        return ResponseEntity.ok(ApiResponse.success(cards));
    }
    
    @GetMapping("/find-with-tag")
    public ResponseEntity<ApiResponse<List<CardDTO>>> searchCards(
            @RequestParam(required = false) List<String> tags,
            @RequestParam(required = false) String search,
            @RequestParam(defaultValue = "zh-Hans") String lang,
            @RequestParam(defaultValue = "OR") String operator) {
        List<CardDTO> cards = cardService.searchCards(tags, search, lang, operator);
        return ResponseEntity.ok(ApiResponse.success(cards));
    }
    
    @GetMapping("/allcounts")
    public ResponseEntity<ApiResponse<Map<Long, Integer>>> getAllCopyCounts() {
        Map<Long, Integer> counts = cardService.getAllCopyCounts();
        return ResponseEntity.ok(ApiResponse.success(counts));
    }
    
    @PostMapping("/{id}/copy")
    public ResponseEntity<ApiResponse<Integer>> updateCopyCount(@PathVariable Long id) {
        Integer count = cardService.updateCopyCount(id);
        return ResponseEntity.ok(ApiResponse.success(count));
    }
}
