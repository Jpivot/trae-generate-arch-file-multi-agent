package com.aishort.backend.repository;

import com.aishort.backend.entity.Card;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CardRepository extends JpaRepository<Card, Long> {
    
    List<Card> findByIdInOrderByIdAsc(List<Long> ids);
    
    List<Card> findByIdIn(List<Long> ids);
    
    @Query("SELECT c FROM Card c JOIN c.tags t WHERE t IN :tags GROUP BY c HAVING COUNT(DISTINCT t) = :tagCount")
    List<Card> findByTagsContainingAll(@Param("tags") List<String> tags, @Param("tagCount") long tagCount);
    
    @Query("SELECT DISTINCT c FROM Card c JOIN c.tags t WHERE t IN :tags")
    List<Card> findByTagsContainingAny(@Param("tags") List<String> tags);
    
    @Query("SELECT c FROM Card c WHERE " +
           "LOWER(c.zhHansData) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(c.enData) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(c.zhHantData) LIKE LOWER(CONCAT('%', :search, '%'))")
    List<Card> searchByContent(@Param("search") String search);
}
