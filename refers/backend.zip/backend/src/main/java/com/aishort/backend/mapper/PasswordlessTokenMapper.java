package com.aishort.backend.mapper;

import com.aishort.backend.entity.PasswordlessToken;
import org.apache.ibatis.annotations.*;

import java.time.LocalDateTime;

@Mapper
public interface PasswordlessTokenMapper {
    
    @Select("SELECT * FROM passwordless_tokens WHERE id = #{id}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "email", column = "email"),
        @Result(property = "loginToken", column = "login_token"),
        @Result(property = "expiresAt", column = "expires_at"),
        @Result(property = "isUsed", column = "is_used"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "createdAt", column = "created_at")
    })
    PasswordlessToken findById(Long id);
    
    @Select("SELECT * FROM passwordless_tokens WHERE login_token = #{loginToken}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "email", column = "email"),
        @Result(property = "loginToken", column = "login_token"),
        @Result(property = "expiresAt", column = "expires_at"),
        @Result(property = "isUsed", column = "is_used"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "createdAt", column = "created_at")
    })
    PasswordlessToken findByLoginToken(String loginToken);
    
    @Select("SELECT * FROM passwordless_tokens WHERE email = #{email} AND is_used = false AND expires_at > #{now}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "email", column = "email"),
        @Result(property = "loginToken", column = "login_token"),
        @Result(property = "expiresAt", column = "expires_at"),
        @Result(property = "isUsed", column = "is_used"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "createdAt", column = "created_at")
    })
    PasswordlessToken findValidByEmail(@Param("email") String email, @Param("now") LocalDateTime now);
    
    @Insert("INSERT INTO passwordless_tokens (email, login_token, expires_at, is_used, user_id, created_at) " +
            "VALUES (#{email}, #{loginToken}, #{expiresAt}, #{isUsed}, #{userId}, NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(PasswordlessToken token);
    
    @Update("UPDATE passwordless_tokens SET is_used = #{isUsed} WHERE id = #{id}")
    int updateUsed(@Param("id") Long id, @Param("isUsed") boolean isUsed);
    
    @Delete("DELETE FROM passwordless_tokens WHERE expires_at < #{time}")
    int deleteExpired(@Param("time") LocalDateTime time);
}
