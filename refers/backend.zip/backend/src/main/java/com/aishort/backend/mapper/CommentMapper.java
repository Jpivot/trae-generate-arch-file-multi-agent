package com.aishort.backend.mapper;

import com.aishort.backend.entity.Comment;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CommentMapper {
    
    @Select("SELECT * FROM comments WHERE id = #{id}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "content", column = "content"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "pageId", column = "page_id"),
        @Result(property = "pageType", column = "page_type"),
        @Result(property = "threadOf", column = "thread_of"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at")
    })
    Comment findById(Long id);
    
    @Select("SELECT * FROM comments WHERE page_id = #{pageId} AND page_type = #{pageType} AND thread_of IS NULL " +
            "ORDER BY id DESC LIMIT #{offset}, #{limit}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "content", column = "content"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "pageId", column = "page_id"),
        @Result(property = "pageType", column = "page_type"),
        @Result(property = "threadOf", column = "thread_of"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at")
    })
    List<Comment> findByPageIdAndType(@Param("pageId") Long pageId, @Param("pageType") String pageType, 
                                       @Param("offset") int offset, @Param("limit") int limit);
    
    @Select("SELECT * FROM comments WHERE thread_of = #{threadOf} ORDER BY id ASC")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "content", column = "content"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "pageId", column = "page_id"),
        @Result(property = "pageType", column = "page_type"),
        @Result(property = "threadOf", column = "thread_of"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at")
    })
    List<Comment> findRepliesByThreadOf(Long threadOf);
    
    @Select("SELECT COUNT(*) FROM comments WHERE page_id = #{pageId} AND page_type = #{pageType} AND thread_of IS NULL")
    long countByPageIdAndType(@Param("pageId") Long pageId, @Param("pageType") String pageType);
    
    @Insert("INSERT INTO comments (content, user_id, page_id, page_type, thread_of, created_at, updated_at) " +
            "VALUES (#{content}, #{userId}, #{pageId}, #{pageType}, #{threadOf}, NOW(), NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Comment comment);
    
    @Delete("DELETE FROM comments WHERE id = #{id}")
    int deleteById(Long id);
}
