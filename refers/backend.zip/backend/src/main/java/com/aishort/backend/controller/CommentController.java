package com.aishort.backend.controller;

import com.aishort.backend.dto.ApiResponse;
import com.aishort.backend.dto.CommentDTO;
import com.aishort.backend.dto.CommentRequest;
import com.aishort.backend.dto.CommentResponse;
import com.aishort.backend.service.CommentService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/comments")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class CommentController {
    
    private final CommentService commentService;
    
    @GetMapping("/api::{type}.{type}:{id}/flat")
    public ResponseEntity<ApiResponse<CommentResponse>> getComments(
            @PathVariable String type,
            @PathVariable Long id,
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "10") int pageSize) {
        CommentResponse response = commentService.getComments(id, page, pageSize, type);
        return ResponseEntity.ok(ApiResponse.success(response));
    }
    
    @PostMapping("/api::{type}.{type}:{pageId}")
    public ResponseEntity<ApiResponse<CommentDTO>> postComment(
            @RequestAttribute("userId") Long userId,
            @PathVariable String type,
            @PathVariable Long pageId,
            @Valid @RequestBody CommentRequest request) {
        CommentDTO comment = commentService.postComment(userId, pageId, request, type);
        return ResponseEntity.ok(ApiResponse.success(comment));
    }
}
