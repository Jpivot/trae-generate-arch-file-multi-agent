package com.aishort.backend.repository;

import com.aishort.backend.entity.Favorite;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FavoriteRepository extends JpaRepository<Favorite, Long> {
    
    Optional<Favorite> findByUserId(Long userId);
    
    boolean existsByUserId(Long userId);
}
