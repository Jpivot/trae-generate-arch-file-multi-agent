package com.aishort.backend.controller;

import com.aishort.backend.dto.ApiResponse;
import com.aishort.backend.dto.MySpaceResponse;
import com.aishort.backend.service.FavoriteService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/myspace")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class MySpaceController {
    
    private final FavoriteService favoriteService;
    
    @GetMapping
    public ResponseEntity<ApiResponse<MySpaceResponse>> getMySpace(
            @RequestAttribute("userId") Long userId) {
        MySpaceResponse response = favoriteService.getMySpace(userId);
        return ResponseEntity.ok(ApiResponse.success(response));
    }
}
