package com.aishort.backend.controller;

import com.aishort.backend.dto.ApiResponse;
import com.aishort.backend.dto.FavoriteRequest;
import com.aishort.backend.service.FavoriteService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/favorites")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class FavoriteController {
    
    private final FavoriteService favoriteService;
    
    @PostMapping
    public ResponseEntity<ApiResponse<Void>> createFavorite(
            @RequestAttribute("userId") Long userId,
            @RequestBody FavoriteRequest request,
            @RequestParam(defaultValue = "false") boolean isComm) {
        favoriteService.createFavorite(userId, request, isComm);
        return ResponseEntity.ok(ApiResponse.success("Favorite created", null));
    }
    
    @PutMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> updateFavorite(
            @RequestAttribute("userId") Long userId,
            @PathVariable Long id,
            @RequestBody FavoriteRequest request,
            @RequestParam(defaultValue = "false") boolean isComm) {
        favoriteService.updateFavorite(userId, id, request, isComm);
        return ResponseEntity.ok(ApiResponse.success("Favorite updated", null));
    }
    
    @PatchMapping("/myspace-order")
    public ResponseEntity<ApiResponse<Void>> updateMySpaceOrder(
            @RequestAttribute("userId") Long userId,
            @RequestBody List<Map<String, Object>> order) {
        favoriteService.updateMySpaceOrder(userId, order);
        return ResponseEntity.ok(ApiResponse.success("Order updated", null));
    }
    
    @PatchMapping("/custom-tags")
    public ResponseEntity<ApiResponse<Void>> updateCustomTags(
            @RequestAttribute("userId") Long userId,
            @RequestBody Map<String, Object> customTags) {
        favoriteService.updateCustomTags(userId, customTags);
        return ResponseEntity.ok(ApiResponse.success("Custom tags updated", null));
    }
    
    @PutMapping("/update-username")
    public ResponseEntity<ApiResponse<Void>> updateUsername(
            @RequestAttribute("userId") Long userId,
            @RequestBody Map<String, String> request) {
        favoriteService.updateMySpaceOrder(userId, List.of());
        return ResponseEntity.ok(ApiResponse.success("Username updated", null));
    }
}
