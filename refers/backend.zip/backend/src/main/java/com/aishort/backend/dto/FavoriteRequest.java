package com.aishort.backend.dto;

import lombok.Data;

import java.util.List;

@Data
public class FavoriteRequest {
    
    private List<Integer> loves;
    private List<Integer> commLoves;
}
