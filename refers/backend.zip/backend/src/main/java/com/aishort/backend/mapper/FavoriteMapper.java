package com.aishort.backend.mapper;

import com.aishort.backend.entity.Favorite;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface FavoriteMapper {
    
    @Select("SELECT * FROM favorites WHERE id = #{id}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "myspaceOrder", column = "myspace_order"),
        @Result(property = "customTags", column = "custom_tags"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    Favorite findById(Long id);
    
    @Select("SELECT * FROM favorites WHERE user_id = #{userId}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "myspaceOrder", column = "myspace_order"),
        @Result(property = "customTags", column = "custom_tags"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    Favorite findByUserId(Long userId);
    
    @Select("SELECT COUNT(*) FROM favorites WHERE user_id = #{userId}")
    int countByUserId(Long userId);
    
    default boolean existsByUserId(Long userId) {
        return countByUserId(userId) > 0;
    }
    
    @Insert("INSERT INTO favorites (user_id, myspace_order, custom_tags, created_at, updated_at) " +
            "VALUES (#{userId}, #{myspaceOrder}, #{customTags}, NOW(), NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(Favorite favorite);
    
    @Update("UPDATE favorites SET myspace_order = #{myspaceOrder}, custom_tags = #{customTags}, " +
            "updated_at = NOW(), version = version + 1 WHERE id = #{id}")
    int update(Favorite favorite);
    
    @Update("UPDATE favorites SET updated_at = NOW() WHERE id = #{id}")
    int touch(Long id);
    
    @Select("SELECT card_id FROM favorite_loves WHERE favorite_id = #{favoriteId}")
    List<Integer> findLovesByFavoriteId(Long favoriteId);
    
    @Select("SELECT prompt_id FROM favorite_comm_loves WHERE favorite_id = #{favoriteId}")
    List<Integer> findCommLovesByFavoriteId(Long favoriteId);
    
    @Insert("INSERT INTO favorite_loves (favorite_id, card_id) VALUES (#{favoriteId}, #{cardId})")
    int insertLove(@Param("favoriteId") Long favoriteId, @Param("cardId") Integer cardId);
    
    @Insert("INSERT INTO favorite_comm_loves (favorite_id, prompt_id) VALUES (#{favoriteId}, #{promptId})")
    int insertCommLove(@Param("favoriteId") Long favoriteId, @Param("promptId") Integer promptId);
    
    @Delete("DELETE FROM favorite_loves WHERE favorite_id = #{favoriteId}")
    int deleteAllLoves(Long favoriteId);
    
    @Delete("DELETE FROM favorite_comm_loves WHERE favorite_id = #{favoriteId}")
    int deleteAllCommLoves(Long favoriteId);
}
