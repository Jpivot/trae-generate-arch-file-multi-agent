package com.aishort.backend.entity;

import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Favorite implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private Long userId;
    private List<Integer> loves;
    private List<Integer> commLoves;
    private String myspaceOrder;
    private String customTags;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Long version;
    
    // 关联用户，非数据库字段
    private User user;
}
