package com.aishort.backend.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserPromptDTO {
    
    private Long id;
    private String title;
    private String description;
    private String remark;
    private String notes;
    private Integer promptLength;
    private Boolean shared;
    private Integer upvotes;
    private Integer downvotes;
    private Integer upvoteDifference;
    private Long userId;
    private String username;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
}
