package com.aishort.backend.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UserPromptRequest {
    
    @NotBlank(message = "Title is required")
    @Size(max = 200, message = "Title must be less than 200 characters")
    private String title;
    
    @NotBlank(message = "Description is required")
    @Size(max = 5000, message = "Description must be less than 5000 characters")
    private String description;
    
    @Size(max = 2000, message = "Remark must be less than 2000 characters")
    private String remark;
    
    @Size(max = 2000, message = "Notes must be less than 2000 characters")
    private String notes;
    
    private Boolean share;
}
