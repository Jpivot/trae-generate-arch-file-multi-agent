package com.aishort.backend.service;

import com.aishort.backend.dto.FavoriteRequest;
import com.aishort.backend.dto.MySpaceResponse;
import com.aishort.backend.entity.Favorite;
import com.aishort.backend.entity.User;
import com.aishort.backend.entity.UserPrompt;
import com.aishort.backend.mapper.FavoriteMapper;
import com.aishort.backend.mapper.UserMapper;
import com.aishort.backend.mapper.UserPromptMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class FavoriteService {
    
    private final FavoriteMapper favoriteMapper;
    private final UserMapper userMapper;
    private final UserPromptMapper userPromptMapper;
    private final ObjectMapper objectMapper;
    
    @Transactional
    public void createFavorite(Long userId, FavoriteRequest request, boolean isComm) {
        User user = userMapper.findById(userId);
        if (user == null) {
            throw new RuntimeException("User not found");
        }
        
        Favorite favorite = Favorite.builder()
                .userId(userId)
                .loves(isComm ? new ArrayList<>() : (request.getLoves() != null ? request.getLoves() : new ArrayList<>()))
                .commLoves(isComm ? (request.getCommLoves() != null ? request.getCommLoves() : new ArrayList<>()) : new ArrayList<>())
                .build();
        
        favoriteMapper.insert(favorite);
        
        // Insert loves
        if (favorite.getLoves() != null) {
            for (Integer cardId : favorite.getLoves()) {
                favoriteMapper.insertLove(favorite.getId(), cardId);
            }
        }
        
        // Insert commLoves
        if (favorite.getCommLoves() != null) {
            for (Integer promptId : favorite.getCommLoves()) {
                favoriteMapper.insertCommLove(favorite.getId(), promptId);
            }
        }
    }
    
    @Transactional
    public void updateFavorite(Long userId, Long favoriteId, FavoriteRequest request, boolean isComm) {
        Favorite favorite = favoriteMapper.findById(favoriteId);
        if (favorite == null) {
            throw new RuntimeException("Favorite not found");
        }
        
        if (!favorite.getUserId().equals(userId)) {
            throw new RuntimeException("Not authorized");
        }
        
        if (isComm) {
            favoriteMapper.deleteAllCommLoves(favoriteId);
            List<Integer> commLoves = request.getCommLoves() != null ? request.getCommLoves() : new ArrayList<>();
            for (Integer promptId : commLoves) {
                favoriteMapper.insertCommLove(favoriteId, promptId);
            }
        } else {
            favoriteMapper.deleteAllLoves(favoriteId);
            List<Integer> loves = request.getLoves() != null ? request.getLoves() : new ArrayList<>();
            for (Integer cardId : loves) {
                favoriteMapper.insertLove(favoriteId, cardId);
            }
        }
        
        favoriteMapper.touch(favoriteId);
    }
    
    @Transactional
    public void updateMySpaceOrder(Long userId, List<Map<String, Object>> order) {
        Favorite favorite = favoriteMapper.findByUserId(userId);
        if (favorite == null) {
            throw new RuntimeException("Favorite not found");
        }
        
        try {
            favorite.setMyspaceOrder(objectMapper.writeValueAsString(order));
            favoriteMapper.update(favorite);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to serialize order");
        }
    }
    
    @Transactional
    public void updateCustomTags(Long userId, Map<String, Object> customTags) {
        Favorite favorite = favoriteMapper.findByUserId(userId);
        if (favorite == null) {
            throw new RuntimeException("Favorite not found");
        }
        
        try {
            favorite.setCustomTags(objectMapper.writeValueAsString(customTags));
            favoriteMapper.update(favorite);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Failed to serialize custom tags");
        }
    }
    
    @Transactional(readOnly = true)
    public MySpaceResponse getMySpace(Long userId) {
        Favorite favorite = favoriteMapper.findByUserId(userId);
        
        if (favorite == null) {
            // Create default favorite
            User user = userMapper.findById(userId);
            if (user == null) {
                throw new RuntimeException("User not found");
            }
            favorite = Favorite.builder()
                    .userId(userId)
                    .loves(new ArrayList<>())
                    .commLoves(new ArrayList<>())
                    .build();
            favoriteMapper.insert(favorite);
        }
        
        // Load loves and commLoves
        List<Integer> loves = favoriteMapper.findLovesByFavoriteId(favorite.getId());
        List<Integer> commLoves = favoriteMapper.findCommLovesByFavoriteId(favorite.getId());
        favorite.setLoves(loves);
        favorite.setCommLoves(commLoves);
        
        // Build items from loves and commLoves
        List<MySpaceResponse.MySpaceItem> items = new ArrayList<>();
        
        // Add card favorites
        for (Integer cardId : loves) {
            items.add(MySpaceResponse.MySpaceItem.builder()
                    .id(cardId.longValue())
                    .type("favorite")
                    .source("card")
                    .build());
        }
        
        // Add community favorites
        if (!commLoves.isEmpty()) {
            List<Long> commIds = commLoves.stream()
                    .map(Integer::longValue)
                    .collect(Collectors.toList());
            List<UserPrompt> commPrompts = userPromptMapper.findByIdIn(commIds);
            
            for (UserPrompt prompt : commPrompts) {
                items.add(MySpaceResponse.MySpaceItem.builder()
                        .id(prompt.getId())
                        .type("favorite")
                        .source("community")
                        .title(prompt.getTitle())
                        .description(prompt.getDescription())
                        .updatedAt(prompt.getUpdatedAt())
                        .build());
            }
        }
        
        // Add user's own prompts
        List<UserPrompt> userPrompts = userPromptMapper.findByUserId(userId);
        for (UserPrompt prompt : userPrompts) {
            items.add(MySpaceResponse.MySpaceItem.builder()
                    .id(prompt.getId())
                    .type("prompt")
                    .source("userprompt")
                    .title(prompt.getTitle())
                    .description(prompt.getDescription())
                    .updatedAt(prompt.getUpdatedAt())
                    .build());
        }
        
        // Parse custom tags
        MySpaceResponse.CustomTags customTags = null;
        if (favorite.getCustomTags() != null) {
            try {
                customTags = objectMapper.readValue(favorite.getCustomTags(), MySpaceResponse.CustomTags.class);
            } catch (JsonProcessingException e) {
                // Use default
            }
        }
        
        if (customTags == null) {
            customTags = MySpaceResponse.CustomTags.builder()
                    .definitions(new ArrayList<>())
                    .itemTags(new HashMap<>())
                    .build();
        }
        
        return MySpaceResponse.builder()
                .items(items)
                .customTags(customTags)
                .updatedAt(favorite.getUpdatedAt())
                .build();
    }
}
