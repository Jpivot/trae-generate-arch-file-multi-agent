package com.aishort.backend.repository;

import com.aishort.backend.entity.CardCount;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CardCountRepository extends JpaRepository<CardCount, Long> {
    
    Optional<CardCount> findByCardId(Long cardId);
    
    List<CardCount> findByCardIdIn(List<Long> cardIds);
}
