package com.aishort.backend.entity;

import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Comment implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private String content;
    private Long userId;
    private Long pageId;
    private String pageType;
    private Long threadOf;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    
    // 关联属性，非数据库字段
    private User user;
    private List<Comment> replies;
}
