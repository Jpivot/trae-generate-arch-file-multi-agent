package com.aishort.backend.entity;

import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class PasswordlessToken implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private String email;
    private String loginToken;
    private LocalDateTime expiresAt;
    private Boolean isUsed;
    private Long userId;
    private LocalDateTime createdAt;
    
    // 关联用户，非数据库字段
    private User user;
    
    public boolean isExpired() {
        return LocalDateTime.now().isAfter(expiresAt);
    }
}
