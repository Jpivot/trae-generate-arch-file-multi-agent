package com.aishort.backend.repository;

import com.aishort.backend.entity.PasswordlessToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.Optional;

@Repository
public interface PasswordlessTokenRepository extends JpaRepository<PasswordlessToken, Long> {
    
    Optional<PasswordlessToken> findByLoginToken(String loginToken);
    
    Optional<PasswordlessToken> findByEmailAndIsUsedFalseAndExpiresAtAfter(String email, LocalDateTime now);
    
    void deleteByExpiresAtBefore(LocalDateTime time);
}
