package com.aishort.backend.entity;

import lombok.*;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class UserPrompt implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private String title;
    private String description;
    private String remark;
    private String notes;
    private Integer promptLength;
    private Boolean shared;
    private Integer upvotes;
    private Integer downvotes;
    private Long userId;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private Long version;
    
    // 关联用户，非数据库字段
    private User user;
    
    public int getUpvoteDifference() {
        return (upvotes != null ? upvotes : 0) - (downvotes != null ? downvotes : 0);
    }
}
