package com.aishort.backend.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MySpaceResponse {
    
    private List<MySpaceItem> items;
    private CustomTags customTags;
    private LocalDateTime updatedAt;
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class MySpaceItem {
        private Long id;
        private String type; // prompt, favorite
        private String source; // userprompt, community, card
        private String title;
        private String description;
        private LocalDateTime updatedAt;
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class CustomTags {
        private List<TagDefinition> definitions;
        private java.util.Map<String, List<String>> itemTags;
    }
    
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class TagDefinition {
        private String id;
        private String name;
        private String color;
        private Integer order;
    }
}
