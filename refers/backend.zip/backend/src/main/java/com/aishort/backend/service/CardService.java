package com.aishort.backend.service;

import com.aishort.backend.dto.CardDTO;
import com.aishort.backend.entity.Card;
import com.aishort.backend.entity.CardCount;
import com.aishort.backend.mapper.CardCountMapper;
import com.aishort.backend.mapper.CardMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CardService {
    
    private final CardMapper cardMapper;
    private final CardCountMapper cardCountMapper;
    private final ObjectMapper objectMapper;
    
    @Transactional(readOnly = true)
    public List<CardDTO> getCardsByIds(List<Integer> ids, String lang) {
        if (ids == null || ids.isEmpty()) {
            return new ArrayList<>();
        }
        
        List<Long> longIds = ids.stream().map(Integer::longValue).collect(Collectors.toList());
        List<Card> cards = cardMapper.findByIdIn(longIds);
        
        return cards.stream()
                .map(card -> mapToDTO(card, lang))
                .collect(Collectors.toList());
    }
    
    @Transactional(readOnly = true)
    public List<CardDTO> searchCards(List<String> tags, String search, String lang, String operator) {
        List<Card> cards = cardMapper.findAll();
        
        // Load tags for each card
        for (Card card : cards) {
            List<String> cardTags = cardMapper.findTagsByCardId(card.getId());
            card.setTags(cardTags);
        }
        
        // Filter by tags
        if (tags != null && !tags.isEmpty()) {
            final List<String> filterTags = tags.stream()
                    .map(String::toLowerCase)
                    .collect(Collectors.toList());
            
            cards = cards.stream()
                    .filter(card -> {
                        List<String> cardTags = card.getTags();
                        if (cardTags == null) return false;
                        
                        List<String> lowerCardTags = cardTags.stream()
                                .map(String::toLowerCase)
                                .collect(Collectors.toList());
                        
                        if ("AND".equalsIgnoreCase(operator)) {
                            return lowerCardTags.containsAll(filterTags);
                        } else {
                            return filterTags.stream().anyMatch(lowerCardTags::contains);
                        }
                    })
                    .collect(Collectors.toList());
        }
        
        // Filter by search
        if (search != null && !search.isEmpty()) {
            String lowerSearch = search.toLowerCase();
            cards = cards.stream()
                    .filter(card -> {
                        String data = card.getDataByLang(lang);
                        return data != null && data.toLowerCase().contains(lowerSearch);
                    })
                    .collect(Collectors.toList());
        }
        
        return cards.stream()
                .map(card -> mapToDTO(card, lang))
                .collect(Collectors.toList());
    }
    
    @Transactional(readOnly = true)
    public Map<Long, Integer> getAllCopyCounts() {
        List<CardCount> counts = cardCountMapper.findAll();
        
        Map<Long, Integer> result = new HashMap<>();
        for (CardCount count : counts) {
            result.put(count.getCardId(), count.getCopyCount());
        }
        
        return result;
    }
    
    @Transactional
    public Integer updateCopyCount(Long cardId) {
        CardCount cardCount = cardCountMapper.findByCardId(cardId);
        if (cardCount == null) {
            Card card = cardMapper.findById(cardId);
            if (card == null) {
                throw new RuntimeException("Card not found");
            }
            cardCount = CardCount.builder()
                    .cardId(cardId)
                    .copyCount(0)
                    .build();
            cardCountMapper.insert(cardCount);
        }
        
        cardCountMapper.incrementCopyCount(cardId);
        cardCount.setCopyCount(cardCount.getCopyCount() + 1);
        
        return cardCount.getCopyCount();
    }
    
    private CardDTO mapToDTO(Card card, String lang) {
        Object langData = parseJson(card.getDataByLang(lang));
        
        CardCount count = cardCountMapper.findByCardId(card.getId());
        Integer copyCount = count != null ? count.getCopyCount() : 0;
        
        // Load tags
        List<String> tags = cardMapper.findTagsByCardId(card.getId());
        
        return CardDTO.builder()
                .id(card.getId())
                .zhHans(parseJson(card.getZhHansData()))
                .en(parseJson(card.getEnData()))
                .ja(parseJson(card.getJaData()))
                .ko(parseJson(card.getKoData()))
                .es(parseJson(card.getEsData()))
                .pt(parseJson(card.getPtData()))
                .fr(parseJson(card.getFrData()))
                .de(parseJson(card.getDeData()))
                .it(parseJson(card.getItData()))
                .ru(parseJson(card.getRuData()))
                .hi(parseJson(card.getHiData()))
                .ar(parseJson(card.getArData()))
                .bn(parseJson(card.getBnData()))
                .tags(tags)
                .website(card.getWebsite())
                .weight(card.getWeight())
                .count(copyCount)
                .build();
    }
    
    private Object parseJson(String json) {
        if (json == null || json.isEmpty()) {
            return null;
        }
        try {
            return objectMapper.readValue(json, Object.class);
        } catch (JsonProcessingException e) {
            return null;
        }
    }
}
