package com.aishort.backend.mapper;

import com.aishort.backend.entity.CardCount;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CardCountMapper {
    
    @Select("SELECT * FROM card_counts WHERE id = #{id}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "cardId", column = "card_id"),
        @Result(property = "copyCount", column = "copy_count")
    })
    CardCount findById(Long id);
    
    @Select("SELECT * FROM card_counts WHERE card_id = #{cardId}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "cardId", column = "card_id"),
        @Result(property = "copyCount", column = "copy_count")
    })
    CardCount findByCardId(Long cardId);
    
    @Select("<script>" +
            "SELECT * FROM card_counts WHERE card_id IN " +
            "<foreach item='id' index='index' collection='cardIds' open='(' separator=',' close=')'>#{id}</foreach>" +
            "</script>")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "cardId", column = "card_id"),
        @Result(property = "copyCount", column = "copy_count")
    })
    List<CardCount> findByCardIdIn(@Param("cardIds") List<Long> cardIds);
    
    @Select("SELECT * FROM card_counts")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "cardId", column = "card_id"),
        @Result(property = "copyCount", column = "copy_count")
    })
    List<CardCount> findAll();
    
    @Insert("INSERT INTO card_counts (card_id, copy_count) VALUES (#{cardId}, #{copyCount})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(CardCount cardCount);
    
    @Update("UPDATE card_counts SET copy_count = #{copyCount} WHERE id = #{id}")
    int update(CardCount cardCount);
    
    @Update("UPDATE card_counts SET copy_count = copy_count + 1 WHERE card_id = #{cardId}")
    int incrementCopyCount(Long cardId);
}
