package com.aishort.backend.service;

import com.aishort.backend.dto.CommentDTO;
import com.aishort.backend.dto.CommentRequest;
import com.aishort.backend.dto.CommentResponse;
import com.aishort.backend.entity.Comment;
import com.aishort.backend.entity.User;
import com.aishort.backend.mapper.CommentMapper;
import com.aishort.backend.mapper.UserMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class CommentService {
    
    private final CommentMapper commentMapper;
    private final UserMapper userMapper;
    
    @Transactional(readOnly = true)
    public CommentResponse getComments(Long pageId, int page, int pageSize, String type) {
        int offset = (page - 1) * pageSize;
        List<Comment> commentList = commentMapper.findByPageIdAndType(pageId, type, offset, pageSize);
        long total = commentMapper.countByPageIdAndType(pageId, type);
        int pageCount = (int) Math.ceil((double) total / pageSize);
        
        List<CommentDTO> comments = commentList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        return CommentResponse.builder()
                .data(comments)
                .pagination(CommentResponse.Pagination.builder()
                        .page(page)
                        .pageSize(pageSize)
                        .pageCount(pageCount)
                        .total(total)
                        .build())
                .build();
    }
    
    @Transactional
    public CommentDTO postComment(Long userId, Long pageId, CommentRequest request, String type) {
        User user = userMapper.findById(userId);
        if (user == null) {
            throw new RuntimeException("User not found");
        }
        
        Comment comment = Comment.builder()
                .content(request.getContent())
                .userId(userId)
                .pageId(pageId)
                .pageType(type)
                .threadOf(request.getThreadOf())
                .build();
        
        commentMapper.insert(comment);
        comment.setUser(user);
        
        return mapToDTO(comment);
    }
    
    private CommentDTO mapToDTO(Comment comment) {
        User user = comment.getUser();
        if (user == null && comment.getUserId() != null) {
            user = userMapper.findById(comment.getUserId());
        }
        
        // Load replies
        List<Comment> replies = commentMapper.findRepliesByThreadOf(comment.getId());
        List<CommentDTO> replyDTOs = replies.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        return CommentDTO.builder()
                .id(comment.getId())
                .content(comment.getContent())
                .userId(comment.getUserId())
                .username(user != null ? user.getUsername() : null)
                .createdAt(comment.getCreatedAt())
                .replies(replyDTOs)
                .build();
    }
}
