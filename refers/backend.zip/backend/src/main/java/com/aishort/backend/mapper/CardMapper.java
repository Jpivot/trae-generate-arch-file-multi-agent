package com.aishort.backend.mapper;

import com.aishort.backend.entity.Card;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface CardMapper {
    
    @Select("SELECT * FROM cards WHERE id = #{id}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "zhHansData", column = "zh_hans_data"),
        @Result(property = "zhHantData", column = "zh_hant_data"),
        @Result(property = "enData", column = "en_data"),
        @Result(property = "jaData", column = "ja_data"),
        @Result(property = "koData", column = "ko_data"),
        @Result(property = "esData", column = "es_data"),
        @Result(property = "ptData", column = "pt_data"),
        @Result(property = "frData", column = "fr_data"),
        @Result(property = "deData", column = "de_data"),
        @Result(property = "itData", column = "it_data"),
        @Result(property = "ruData", column = "ru_data"),
        @Result(property = "hiData", column = "hi_data"),
        @Result(property = "arData", column = "ar_data"),
        @Result(property = "bnData", column = "bn_data"),
        @Result(property = "website", column = "website"),
        @Result(property = "weight", column = "weight")
    })
    Card findById(Long id);
    
    @Select("<script>" +
            "SELECT * FROM cards WHERE id IN " +
            "<foreach item='id' index='index' collection='ids' open='(' separator=',' close=')'>#{id}</foreach> " +
            "ORDER BY id ASC" +
            "</script>")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "zhHansData", column = "zh_hans_data"),
        @Result(property = "zhHantData", column = "zh_hant_data"),
        @Result(property = "enData", column = "en_data"),
        @Result(property = "jaData", column = "ja_data"),
        @Result(property = "koData", column = "ko_data"),
        @Result(property = "esData", column = "es_data"),
        @Result(property = "ptData", column = "pt_data"),
        @Result(property = "frData", column = "fr_data"),
        @Result(property = "deData", column = "de_data"),
        @Result(property = "itData", column = "it_data"),
        @Result(property = "ruData", column = "ru_data"),
        @Result(property = "hiData", column = "hi_data"),
        @Result(property = "arData", column = "ar_data"),
        @Result(property = "bnData", column = "bn_data"),
        @Result(property = "website", column = "website"),
        @Result(property = "weight", column = "weight")
    })
    List<Card> findByIdIn(@Param("ids") List<Long> ids);
    
    @Select("SELECT * FROM cards")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "zhHansData", column = "zh_hans_data"),
        @Result(property = "zhHantData", column = "zh_hant_data"),
        @Result(property = "enData", column = "en_data"),
        @Result(property = "jaData", column = "ja_data"),
        @Result(property = "koData", column = "ko_data"),
        @Result(property = "esData", column = "es_data"),
        @Result(property = "ptData", column = "pt_data"),
        @Result(property = "frData", column = "fr_data"),
        @Result(property = "deData", column = "de_data"),
        @Result(property = "itData", column = "it_data"),
        @Result(property = "ruData", column = "ru_data"),
        @Result(property = "hiData", column = "hi_data"),
        @Result(property = "arData", column = "ar_data"),
        @Result(property = "bnData", column = "bn_data"),
        @Result(property = "website", column = "website"),
        @Result(property = "weight", column = "weight")
    })
    List<Card> findAll();
    
    @Select("SELECT tag FROM card_tags WHERE card_id = #{cardId}")
    List<String> findTagsByCardId(Long cardId);
    
    @Insert("INSERT INTO cards (id, zh_hans_data, zh_hant_data, en_data, ja_data, ko_data, es_data, pt_data, " +
            "fr_data, de_data, it_data, ru_data, hi_data, ar_data, bn_data, website, weight) " +
            "VALUES (#{id}, #{zhHansData}, #{zhHantData}, #{enData}, #{jaData}, #{koData}, #{esData}, #{ptData}, " +
            "#{frData}, #{deData}, #{itData}, #{ruData}, #{hiData}, #{arData}, #{bnData}, #{website}, #{weight})")
    int insert(Card card);
    
    @Insert("INSERT INTO card_tags (card_id, tag) VALUES (#{cardId}, #{tag})")
    int insertTag(@Param("cardId") Long cardId, @Param("tag") String tag);
    
    @Delete("DELETE FROM card_tags WHERE card_id = #{cardId}")
    int deleteTagsByCardId(Long cardId);
}
