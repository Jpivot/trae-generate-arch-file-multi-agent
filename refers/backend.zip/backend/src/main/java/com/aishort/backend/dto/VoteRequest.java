package com.aishort.backend.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import lombok.Data;

@Data
public class VoteRequest {
    
    @NotBlank(message = "Action is required")
    @Pattern(regexp = "^(upvote|downvote)$", message = "Action must be 'upvote' or 'downvote'")
    private String action;
}
