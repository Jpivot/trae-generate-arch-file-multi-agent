package com.aishort.backend.mapper;

import com.aishort.backend.entity.UserPrompt;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserPromptMapper {
    
    @Select("SELECT * FROM user_prompts WHERE id = #{id}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "title", column = "title"),
        @Result(property = "description", column = "description"),
        @Result(property = "remark", column = "remark"),
        @Result(property = "notes", column = "notes"),
        @Result(property = "promptLength", column = "prompt_length"),
        @Result(property = "shared", column = "is_shared"),
        @Result(property = "upvotes", column = "upvotes"),
        @Result(property = "downvotes", column = "downvotes"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    UserPrompt findById(Long id);
    
    @Select("SELECT * FROM user_prompts WHERE user_id = #{userId}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "title", column = "title"),
        @Result(property = "description", column = "description"),
        @Result(property = "remark", column = "remark"),
        @Result(property = "notes", column = "notes"),
        @Result(property = "promptLength", column = "prompt_length"),
        @Result(property = "shared", column = "is_shared"),
        @Result(property = "upvotes", column = "upvotes"),
        @Result(property = "downvotes", column = "downvotes"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    List<UserPrompt> findByUserId(Long userId);
    
    @Select("SELECT * FROM user_prompts WHERE is_shared = true ORDER BY upvotes - downvotes DESC LIMIT #{offset}, #{limit}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "title", column = "title"),
        @Result(property = "description", column = "description"),
        @Result(property = "remark", column = "remark"),
        @Result(property = "notes", column = "notes"),
        @Result(property = "promptLength", column = "prompt_length"),
        @Result(property = "shared", column = "is_shared"),
        @Result(property = "upvotes", column = "upvotes"),
        @Result(property = "downvotes", column = "downvotes"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    List<UserPrompt> findSharedWithPagination(@Param("offset") int offset, @Param("limit") int limit);
    
    @Select("SELECT COUNT(*) FROM user_prompts WHERE is_shared = true")
    long countShared();
    
    @Select("<script>" +
            "SELECT * FROM user_prompts WHERE is_shared = true AND " +
            "(title LIKE CONCAT('%', #{search}, '%') OR description LIKE CONCAT('%', #{search}, '%') OR remark LIKE CONCAT('%', #{search}, '%')) " +
            "ORDER BY upvotes - downvotes DESC LIMIT #{offset}, #{limit}" +
            "</script>")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "title", column = "title"),
        @Result(property = "description", column = "description"),
        @Result(property = "remark", column = "remark"),
        @Result(property = "notes", column = "notes"),
        @Result(property = "promptLength", column = "prompt_length"),
        @Result(property = "shared", column = "is_shared"),
        @Result(property = "upvotes", column = "upvotes"),
        @Result(property = "downvotes", column = "downvotes"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    List<UserPrompt> searchShared(@Param("search") String search, @Param("offset") int offset, @Param("limit") int limit);
    
    @Select("<script>" +
            "SELECT COUNT(*) FROM user_prompts WHERE is_shared = true AND " +
            "(title LIKE CONCAT('%', #{search}, '%') OR description LIKE CONCAT('%', #{search}, '%') OR remark LIKE CONCAT('%', #{search}, '%'))" +
            "</script>")
    long countSharedSearch(@Param("search") String search);
    
    @Select("<script>" +
            "SELECT * FROM user_prompts WHERE id IN " +
            "<foreach item='id' index='index' collection='ids' open='(' separator=',' close=')'>#{id}</foreach>" +
            "</script>")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "title", column = "title"),
        @Result(property = "description", column = "description"),
        @Result(property = "remark", column = "remark"),
        @Result(property = "notes", column = "notes"),
        @Result(property = "promptLength", column = "prompt_length"),
        @Result(property = "shared", column = "is_shared"),
        @Result(property = "upvotes", column = "upvotes"),
        @Result(property = "downvotes", column = "downvotes"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    List<UserPrompt> findByIdIn(@Param("ids") List<Long> ids);
    
    @Select("<script>" +
            "SELECT * FROM user_prompts WHERE id IN " +
            "<foreach item='id' index='index' collection='ids' open='(' separator=',' close=')'>#{id}</foreach> " +
            "AND is_shared = true" +
            "</script>")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "title", column = "title"),
        @Result(property = "description", column = "description"),
        @Result(property = "remark", column = "remark"),
        @Result(property = "notes", column = "notes"),
        @Result(property = "promptLength", column = "prompt_length"),
        @Result(property = "shared", column = "is_shared"),
        @Result(property = "upvotes", column = "upvotes"),
        @Result(property = "downvotes", column = "downvotes"),
        @Result(property = "userId", column = "user_id"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    List<UserPrompt> findByIdInAndShared(@Param("ids") List<Long> ids);
    
    @Insert("INSERT INTO user_prompts (title, description, remark, notes, prompt_length, is_shared, upvotes, downvotes, user_id, created_at, updated_at) " +
            "VALUES (#{title}, #{description}, #{remark}, #{notes}, #{promptLength}, #{shared}, 0, 0, #{userId}, NOW(), NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(UserPrompt prompt);
    
    @Update("UPDATE user_prompts SET title = #{title}, description = #{description}, remark = #{remark}, " +
            "notes = #{notes}, prompt_length = #{promptLength}, is_shared = #{shared}, " +
            "updated_at = NOW(), version = version + 1 WHERE id = #{id}")
    int update(UserPrompt prompt);
    
    @Update("UPDATE user_prompts SET upvotes = #{upvotes}, downvotes = #{downvotes} WHERE id = #{id}")
    int updateVotes(@Param("id") Long id, @Param("upvotes") int upvotes, @Param("downvotes") int downvotes);
    
    @Delete("DELETE FROM user_prompts WHERE id = #{id}")
    int deleteById(Long id);
}
