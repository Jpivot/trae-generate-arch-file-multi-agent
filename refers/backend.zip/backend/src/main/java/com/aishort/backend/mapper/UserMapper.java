package com.aishort.backend.mapper;

import com.aishort.backend.entity.User;
import org.apache.ibatis.annotations.*;

import java.util.Optional;

@Mapper
public interface UserMapper {
    
    @Select("SELECT * FROM users WHERE id = #{id}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "username", column = "username"),
        @Result(property = "email", column = "email"),
        @Result(property = "password", column = "password"),
        @Result(property = "provider", column = "provider"),
        @Result(property = "providerId", column = "provider_id"),
        @Result(property = "resetPasswordToken", column = "reset_password_token"),
        @Result(property = "resetPasswordExpires", column = "reset_password_expires"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    User findById(Long id);
    
    @Select("SELECT * FROM users WHERE username = #{username}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "username", column = "username"),
        @Result(property = "email", column = "email"),
        @Result(property = "password", column = "password"),
        @Result(property = "provider", column = "provider"),
        @Result(property = "providerId", column = "provider_id"),
        @Result(property = "resetPasswordToken", column = "reset_password_token"),
        @Result(property = "resetPasswordExpires", column = "reset_password_expires"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    User findByUsername(String username);
    
    @Select("SELECT * FROM users WHERE email = #{email}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "username", column = "username"),
        @Result(property = "email", column = "email"),
        @Result(property = "password", column = "password"),
        @Result(property = "provider", column = "provider"),
        @Result(property = "providerId", column = "provider_id"),
        @Result(property = "resetPasswordToken", column = "reset_password_token"),
        @Result(property = "resetPasswordExpires", column = "reset_password_expires"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    User findByEmail(String email);
    
    @Select("SELECT * FROM users WHERE reset_password_token = #{token}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "username", column = "username"),
        @Result(property = "email", column = "email"),
        @Result(property = "password", column = "password"),
        @Result(property = "provider", column = "provider"),
        @Result(property = "providerId", column = "provider_id"),
        @Result(property = "resetPasswordToken", column = "reset_password_token"),
        @Result(property = "resetPasswordExpires", column = "reset_password_expires"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    User findByResetPasswordToken(String token);
    
    @Select("SELECT * FROM users WHERE provider = #{provider} AND provider_id = #{providerId}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "username", column = "username"),
        @Result(property = "email", column = "email"),
        @Result(property = "password", column = "password"),
        @Result(property = "provider", column = "provider"),
        @Result(property = "providerId", column = "provider_id"),
        @Result(property = "resetPasswordToken", column = "reset_password_token"),
        @Result(property = "resetPasswordExpires", column = "reset_password_expires"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "version", column = "version")
    })
    User findByProviderAndProviderId(@Param("provider") String provider, @Param("providerId") String providerId);
    
    @Select("SELECT COUNT(*) FROM users WHERE username = #{username}")
    int countByUsername(String username);
    
    @Select("SELECT COUNT(*) FROM users WHERE email = #{email}")
    int countByEmail(String email);
    
    default boolean existsByUsername(String username) {
        return countByUsername(username) > 0;
    }
    
    default boolean existsByEmail(String email) {
        return countByEmail(email) > 0;
    }
    
    @Insert("INSERT INTO users (username, email, password, provider, provider_id, reset_password_token, " +
            "reset_password_expires, created_at, updated_at) " +
            "VALUES (#{username}, #{email}, #{password}, #{provider}, #{providerId}, #{resetPasswordToken}, " +
            "#{resetPasswordExpires}, NOW(), NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    int insert(User user);
    
    @Update("UPDATE users SET username = #{username}, email = #{email}, password = #{password}, " +
            "provider = #{provider}, provider_id = #{providerId}, reset_password_token = #{resetPasswordToken}, " +
            "reset_password_expires = #{resetPasswordExpires}, updated_at = NOW(), version = version + 1 " +
            "WHERE id = #{id}")
    int update(User user);
    
    @Delete("DELETE FROM users WHERE id = #{id}")
    int deleteById(Long id);
}
