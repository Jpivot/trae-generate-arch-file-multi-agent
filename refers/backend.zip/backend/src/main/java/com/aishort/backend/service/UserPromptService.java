package com.aishort.backend.service;

import com.aishort.backend.dto.*;
import com.aishort.backend.entity.User;
import com.aishort.backend.entity.UserPrompt;
import com.aishort.backend.mapper.UserMapper;
import com.aishort.backend.mapper.UserPromptMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserPromptService {
    
    private final UserPromptMapper userPromptMapper;
    private final UserMapper userMapper;
    
    @Transactional(readOnly = true)
    public List<UserPromptDTO> getPromptsByIds(String type, List<Integer> ids, Long userId) {
        if (ids == null || ids.isEmpty()) {
            return new ArrayList<>();
        }
        
        List<Long> longIds = ids.stream().map(Integer::longValue).collect(Collectors.toList());
        
        List<UserPrompt> prompts;
        if ("commus".equals(type) || "cards".equals(type)) {
            prompts = userPromptMapper.findByIdInAndShared(longIds);
        } else {
            prompts = userPromptMapper.findByIdIn(longIds);
        }
        
        return prompts.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }
    
    @Transactional(readOnly = true)
    public Map<String, Object> getCommPrompts(int page, int pageSize, String sortField, String sortOrder, String searchTerm) {
        int offset = (page - 1) * pageSize;
        
        List<UserPrompt> promptList;
        long total;
        
        if (searchTerm != null && !searchTerm.isEmpty()) {
            String search = "%" + searchTerm.trim() + "%";
            promptList = userPromptMapper.searchShared(search, offset, pageSize);
            total = userPromptMapper.countSharedSearch(search);
        } else {
            promptList = userPromptMapper.findSharedWithPagination(offset, pageSize);
            total = userPromptMapper.countShared();
        }
        
        List<UserPromptDTO> data = promptList.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
        
        int pageCount = (int) Math.ceil((double) total / pageSize);
        
        Map<String, Object> pagination = new HashMap<>();
        pagination.put("page", page);
        pagination.put("pageSize", pageSize);
        pagination.put("pageCount", pageCount);
        pagination.put("total", total);
        
        Map<String, Object> result = new HashMap<>();
        result.put("data", data);
        result.put("pagination", pagination);
        
        return result;
    }
    
    @Transactional
    public UserPromptDTO createPrompt(Long userId, UserPromptRequest request) {
        User user = userMapper.findById(userId);
        if (user == null) {
            throw new RuntimeException("User not found");
        }
        
        UserPrompt prompt = UserPrompt.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .remark(request.getRemark())
                .notes(request.getNotes())
                .promptLength(request.getDescription().length())
                .shared(request.getShare() != null ? request.getShare() : false)
                .userId(userId)
                .upvotes(0)
                .downvotes(0)
                .build();
        
        userPromptMapper.insert(prompt);
        prompt.setUser(user);
        
        return mapToDTO(prompt);
    }
    
    @Transactional
    public UserPromptDTO updatePrompt(Long userId, Long promptId, UserPromptRequest request) {
        UserPrompt prompt = userPromptMapper.findById(promptId);
        if (prompt == null) {
            throw new RuntimeException("Prompt not found");
        }
        
        if (!prompt.getUserId().equals(userId)) {
            throw new RuntimeException("Not authorized to update this prompt");
        }
        
        prompt.setTitle(request.getTitle());
        prompt.setDescription(request.getDescription());
        prompt.setRemark(request.getRemark());
        prompt.setNotes(request.getNotes());
        prompt.setPromptLength(request.getDescription().length());
        prompt.setShared(request.getShare() != null ? request.getShare() : prompt.getShared());
        
        userPromptMapper.update(prompt);
        
        return mapToDTO(prompt);
    }
    
    @Transactional
    public void deletePrompt(Long userId, Long promptId) {
        UserPrompt prompt = userPromptMapper.findById(promptId);
        if (prompt == null) {
            throw new RuntimeException("Prompt not found");
        }
        
        if (!prompt.getUserId().equals(userId)) {
            throw new RuntimeException("Not authorized to delete this prompt");
        }
        
        userPromptMapper.deleteById(promptId);
    }
    
    @Transactional
    public VoteResponse voteOnPrompt(Long promptId, String action) {
        UserPrompt prompt = userPromptMapper.findById(promptId);
        if (prompt == null) {
            throw new RuntimeException("Prompt not found");
        }
        
        int upvotes = prompt.getUpvotes() != null ? prompt.getUpvotes() : 0;
        int downvotes = prompt.getDownvotes() != null ? prompt.getDownvotes() : 0;
        
        if ("upvote".equals(action)) {
            upvotes++;
        } else if ("downvote".equals(action)) {
            downvotes++;
        }
        
        userPromptMapper.updateVotes(promptId, upvotes, downvotes);
        
        return VoteResponse.builder()
                .counts(VoteResponse.Counts.builder()
                        .upvotes(upvotes)
                        .downvotes(downvotes)
                        .build())
                .build();
    }
    
    @Transactional(readOnly = true)
    public List<Map<String, Object>> checkUpdates(List<Integer> ids) {
        if (ids == null || ids.isEmpty()) {
            return new ArrayList<>();
        }
        
        List<Long> longIds = ids.stream().map(Integer::longValue).collect(Collectors.toList());
        List<UserPrompt> prompts = userPromptMapper.findByIdIn(longIds);
        
        return prompts.stream()
                .map(p -> {
                    Map<String, Object> map = new HashMap<>();
                    map.put("id", p.getId());
                    map.put("updatedAt", p.getUpdatedAt());
                    return map;
                })
                .collect(Collectors.toList());
    }
    
    private UserPromptDTO mapToDTO(UserPrompt prompt) {
        User user = prompt.getUser();
        if (user == null && prompt.getUserId() != null) {
            user = userMapper.findById(prompt.getUserId());
        }
        
        return UserPromptDTO.builder()
                .id(prompt.getId())
                .title(prompt.getTitle())
                .description(prompt.getDescription())
                .remark(prompt.getRemark())
                .notes(prompt.getNotes())
                .promptLength(prompt.getPromptLength())
                .shared(prompt.getShared())
                .upvotes(prompt.getUpvotes())
                .downvotes(prompt.getDownvotes())
                .upvoteDifference(prompt.getUpvoteDifference())
                .userId(prompt.getUserId())
                .username(user != null ? user.getUsername() : null)
                .createdAt(prompt.getCreatedAt())
                .updatedAt(prompt.getUpdatedAt())
                .build();
    }
}
