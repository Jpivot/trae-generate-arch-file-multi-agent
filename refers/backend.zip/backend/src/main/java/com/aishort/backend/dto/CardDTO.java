package com.aishort.backend.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class CardDTO {
    
    private Long id;
    private Object zhHans;
    private Object en;
    private Object ja;
    private Object ko;
    private Object es;
    private Object pt;
    private Object fr;
    private Object de;
    private Object it;
    private Object ru;
    private Object hi;
    private Object ar;
    private Object bn;
    private List<String> tags;
    private String website;
    private Integer weight;
    private Integer count;
}
