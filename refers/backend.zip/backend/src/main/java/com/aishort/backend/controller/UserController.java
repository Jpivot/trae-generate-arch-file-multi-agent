package com.aishort.backend.controller;

import com.aishort.backend.dto.ApiResponse;
import com.aishort.backend.dto.UpdateUsernameRequest;
import com.aishort.backend.dto.UserDTO;
import com.aishort.backend.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/users")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class UserController {
    
    private final UserService userService;
    
    @GetMapping("/me")
    public ResponseEntity<ApiResponse<UserDTO>> getCurrentUser(
            @RequestAttribute("userId") Long userId) {
        UserDTO user = userService.getUserMe(userId);
        return ResponseEntity.ok(ApiResponse.success(user));
    }
    
    @PutMapping("/update-username")
    public ResponseEntity<ApiResponse<Void>> updateUsername(
            @RequestAttribute("userId") Long userId,
            @Valid @RequestBody UpdateUsernameRequest request) {
        userService.updateUsername(userId, request.getNewUsername());
        return ResponseEntity.ok(ApiResponse.success("Username updated", null));
    }
}
