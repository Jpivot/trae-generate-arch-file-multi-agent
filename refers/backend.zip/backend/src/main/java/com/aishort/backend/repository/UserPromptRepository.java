package com.aishort.backend.repository;

import com.aishort.backend.entity.UserPrompt;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserPromptRepository extends JpaRepository<UserPrompt, Long> {
    
    List<UserPrompt> findByUserId(Long userId);
    
    Page<UserPrompt> findBySharedTrue(Pageable pageable);
    
    @Query("SELECT up FROM UserPrompt up WHERE up.shared = true AND " +
           "(LOWER(up.title) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(up.description) LIKE LOWER(CONCAT('%', :search, '%')) OR " +
           "LOWER(up.remark) LIKE LOWER(CONCAT('%', :search, '%')))" +
           "ORDER BY up.upvotes - up.downvotes DESC")
    Page<UserPrompt> searchSharedPrompts(@Param("search") String search, Pageable pageable);
    
    @Query("SELECT up FROM UserPrompt up WHERE up.id IN :ids AND up.shared = true")
    List<UserPrompt> findByIdInAndSharedTrue(@Param("ids") List<Long> ids);
    
    List<UserPrompt> findByIdIn(List<Long> ids);
    
    @Query("SELECT up FROM UserPrompt up WHERE up.id IN :ids")
    List<UserPrompt> findByIdsWithUser(@Param("ids") List<Long> ids);
}
