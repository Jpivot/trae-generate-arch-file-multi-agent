package com.aishort.backend.entity;

import lombok.*;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Card implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private Long id;
    private String zhHansData;
    private String zhHantData;
    private String enData;
    private String jaData;
    private String koData;
    private String esData;
    private String ptData;
    private String frData;
    private String deData;
    private String itData;
    private String ruData;
    private String hiData;
    private String arData;
    private String bnData;
    private String website;
    private Integer weight;
    private List<String> tags;
    
    // 关联属性，非数据库字段
    private CardCount cardCount;
    
    public String getDataByLang(String lang) {
        switch (lang) {
            case "zh-Hans": return zhHansData;
            case "zh-Hant": return zhHantData;
            case "en": return enData;
            case "ja": return jaData;
            case "ko": return koData;
            case "es": return esData;
            case "pt": return ptData;
            case "fr": return frData;
            case "de": return deData;
            case "it": return itData;
            case "ru": return ruData;
            case "hi": return hiData;
            case "ar": return arData;
            case "bn": return bnData;
            default: return zhHansData;
        }
    }
}
