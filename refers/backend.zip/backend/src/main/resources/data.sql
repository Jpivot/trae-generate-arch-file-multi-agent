-- Initialize default cards (278 cards from AiShort)
-- These are sample entries. In production, import all 278 cards

INSERT INTO cards (id, zh_hans_data, en_data, ja_data, ko_data, es_data, pt_data, fr_data, de_data, it_data, ru_data, hi_data, ar_data, bn_data, website, weight, tags) VALUES
(1, 
 '{"title":"英语翻译/修改","prompt":"I want you to act as an English translator...","description":"我希望你能充当英语翻译...","remark":"将其他语言翻译成英文"}',
 '{"title":"English Translator","prompt":"I want you to act as an English translator...","description":"I want you to act as an English translator...","remark":"Translate other languages to English"}',
 '{"title":"英語翻訳","prompt":"I want you to act as an English translator...","description":"英語の翻訳者として...","remark":"他の言語を英語に翻訳"}',
 NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
 'https://github.com/f/awesome-chatgpt-prompts#act-as-an-english-translator-and-improver',
 21338,
 'language');

-- Insert card count
INSERT INTO card_counts (card_id, copy_count) VALUES (1, 21338);

-- Insert default admin user (password: admin123)
-- Note: In production, use proper password hashing
-- INSERT INTO users (username, email, password, provider, created_at, updated_at) VALUES 
-- ('admin', 'admin@example.com', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5E', 'local', NOW(), NOW());
