-- Drop tables if exist
DROP TABLE IF EXISTS comments;
DROP TABLE IF EXISTS favorite_comm_loves;
DROP TABLE IF EXISTS favorite_loves;
DROP TABLE IF EXISTS card_tags;
DROP TABLE IF EXISTS card_counts;
DROP TABLE IF EXISTS cards;
DROP TABLE IF EXISTS user_prompts;
DROP TABLE IF EXISTS passwordless_tokens;
DROP TABLE IF EXISTS favorites;
DROP TABLE IF EXISTS users;

-- Users table
CREATE TABLE users (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    provider VARCHAR(20) DEFAULT 'local',
    provider_id VARCHAR(100),
    reset_password_token VARCHAR(255),
    reset_password_expires TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    version BIGINT DEFAULT 0
);

-- User prompts table
CREATE TABLE user_prompts (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT NOT NULL,
    remark TEXT,
    notes TEXT,
    prompt_length INT,
    is_shared BOOLEAN DEFAULT FALSE,
    upvotes INT DEFAULT 0,
    downvotes INT DEFAULT 0,
    user_id BIGINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    version BIGINT DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Favorites table
CREATE TABLE favorites (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id BIGINT NOT NULL UNIQUE,
    myspace_order TEXT,
    custom_tags TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    version BIGINT DEFAULT 0,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Favorite loves (card favorites)
CREATE TABLE favorite_loves (
    favorite_id BIGINT NOT NULL,
    card_id INT NOT NULL,
    PRIMARY KEY (favorite_id, card_id),
    FOREIGN KEY (favorite_id) REFERENCES favorites(id) ON DELETE CASCADE
);

-- Favorite community loves
CREATE TABLE favorite_comm_loves (
    favorite_id BIGINT NOT NULL,
    prompt_id INT NOT NULL,
    PRIMARY KEY (favorite_id, prompt_id),
    FOREIGN KEY (favorite_id) REFERENCES favorites(id) ON DELETE CASCADE
);

-- Comments table
CREATE TABLE comments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    content TEXT NOT NULL,
    user_id BIGINT NOT NULL,
    page_id BIGINT NOT NULL,
    page_type VARCHAR(20) NOT NULL,
    thread_of BIGINT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (thread_of) REFERENCES comments(id)
);

-- Cards table (static data)
CREATE TABLE cards (
    id BIGINT PRIMARY KEY,
    zh_hans_data TEXT,
    zh_hant_data TEXT,
    en_data TEXT,
    ja_data TEXT,
    ko_data TEXT,
    es_data TEXT,
    pt_data TEXT,
    fr_data TEXT,
    de_data TEXT,
    it_data TEXT,
    ru_data TEXT,
    hi_data TEXT,
    ar_data TEXT,
    bn_data TEXT,
    website VARCHAR(500),
    weight INT DEFAULT 0
);

-- Card tags
CREATE TABLE card_tags (
    card_id BIGINT NOT NULL,
    tag VARCHAR(50) NOT NULL,
    PRIMARY KEY (card_id, tag),
    FOREIGN KEY (card_id) REFERENCES cards(id)
);

-- Card counts
CREATE TABLE card_counts (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    card_id BIGINT NOT NULL UNIQUE,
    copy_count INT DEFAULT 0,
    FOREIGN KEY (card_id) REFERENCES cards(id)
);

-- Passwordless tokens
CREATE TABLE passwordless_tokens (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    login_token VARCHAR(255) NOT NULL UNIQUE,
    expires_at TIMESTAMP NOT NULL,
    is_used BOOLEAN DEFAULT FALSE,
    user_id BIGINT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Indexes
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_reset_token ON users(reset_password_token);
CREATE INDEX idx_user_prompts_user_id ON user_prompts(user_id);
CREATE INDEX idx_user_prompts_shared ON user_prompts(is_shared);
CREATE INDEX idx_comments_page ON comments(page_id, page_type);
CREATE INDEX idx_comments_thread ON comments(thread_of);
CREATE INDEX idx_passwordless_token ON passwordless_tokens(login_token);
